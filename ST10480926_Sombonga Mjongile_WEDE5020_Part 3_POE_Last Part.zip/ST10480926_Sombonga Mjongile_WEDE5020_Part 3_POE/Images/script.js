/*
  Central script: hamburger, accessibility helpers, toggleInfo (accordion),
  form validation, dynamic products + add-to-cart, cart modal, search filter,
  and a simple lightbox gallery.
*/
(function () {
  // ---------- Helpers ----------
  function qs(sel, ctx) { return (ctx || document).querySelector(sel); }
  function qsa(sel, ctx) { return Array.from((ctx || document).querySelectorAll(sel)); }
  function create(tag, attrs = {}, parent) {
    const el = document.createElement(tag);
    Object.entries(attrs).forEach(([k, v]) => {
      if (k === 'html') el.innerHTML = v;
      else el.setAttribute(k, v);
    });
    if (parent) parent.appendChild(el);
    return el;
  }

  // ---------- Hamburger ----------
  function initHamburger() {
    const nav = qs('#main-nav');
    if (!nav) return;
    let hb = qs('#hamburger-menu');
    if (!hb) {
      const header = qs('header') || document.body;
      hb = create('div', { id: 'hamburger-menu', class: 'hamburger', 'aria-label': 'Open navigation', tabindex: '0' }, header);
      hb.innerHTML = '<span></span><span></span><span></span>';
      header.insertBefore(hb, nav);
    }
    hb.setAttribute('role', 'button');
    hb.setAttribute('aria-controls', 'main-nav');
    hb.setAttribute('aria-expanded', 'false');

    function toggle() {
      const active = nav.classList.toggle('active');
      hb.classList.toggle('open', active);
      hb.setAttribute('aria-expanded', active ? 'true' : 'false');
    }

    if (!hb.__init) {
      hb.addEventListener('click', (e) => { e.stopPropagation(); toggle(); });
      hb.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); } });
      document.addEventListener('click', (e) => {
        if (!nav.contains(e.target) && !hb.contains(e.target)) {
          nav.classList.remove('active'); hb.classList.remove('open'); hb.setAttribute('aria-expanded','false');
        }
      });
      qsa('#main-nav a').forEach(a => a.addEventListener('click', () => { nav.classList.remove('active'); hb.classList.remove('open'); hb.setAttribute('aria-expanded','false'); }));
      hb.__init = true;
    }
  }

  // ---------- Toggle Info (accordion) ----------
  window.toggleInfo = function (elementId, btn) {
    const elem = document.getElementById(elementId);
    if (!elem) return;
    const hidden = elem.classList.toggle('hidden');
    if (btn) btn.setAttribute('aria-expanded', (!hidden).toString());
  };

  function initAccordions() {
    qsa('button[onclick^="toggleInfo"]').forEach(btn => {
      btn.setAttribute('aria-expanded', 'false');
      btn.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); btn.click(); } });
    });
  }

  // ---------- Form validation ----------
  function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
    let ok = true;
    inputs.forEach(input => {
      input.classList.remove('error');
      const val = (input.value || '').trim();
      if (!val) { ok = false; input.classList.add('error'); return; }
      if (input.type === 'email' && !/^\S+@\S+\.\S+$/.test(val)) { ok = false; input.classList.add('error'); }
      if (input.type === 'tel' && input.pattern) {
        const pat = new RegExp(input.pattern);
        if (!pat.test(val)) { ok = false; input.classList.add('error'); }
      }
    });
    return ok;
  }
  function initFormValidation() {
    qsa('form').forEach(form => {
      form.addEventListener('submit', (e) => {
        if (!validateForm(form)) { e.preventDefault(); const firstErr = form.querySelector('.error'); firstErr && firstErr.focus(); }
      });
      qsa('input,textarea,select', form).forEach(i => i.addEventListener('blur', () => i.classList.toggle('error', !i.checkValidity())));
    });
  }

  // ---------- Lightbox ----------
  function initLightbox() {
    if (qs('#lightbox-modal')) return;
    const lb = create('div', { id: 'lightbox-modal', style: 'display:none;position:fixed;inset:0;background:rgba(0,0,0,0.85);align-items:center;justify-content:center;z-index:2000' }, document.body);
    const inner = create('div', { style: 'max-width:90%;max-height:90%' }, lb);
    const img = create('img', { id: 'lightbox-img', style: 'max-width:100%;max-height:100%;border-radius:6px;box-shadow:0 6px 30px rgba(0,0,0,0.6)' }, inner);
    lb.addEventListener('click', (e) => { if (e.target === lb || e.target === img) lb.style.display = 'none'; });
    qsa('.card img, img[data-lightbox]').forEach(image => {
      image.style.cursor = 'zoom-in';
      image.addEventListener('click', () => { img.src = image.src; lb.style.display = 'flex'; });
    });
  }

  // ---------- Cart & products ----------
  const defaultProducts = [
    { id: 1, name: 'Maroon Blazer', price: 899.99, image: 'blazer.jpg', description: 'Premium maroon blazer with tailored fit.' },
    { id: 2, name: 'Black Formal Dress', price: 1299.99, image: 'dress.jpg', description: 'Elegant black formal dress perfect for events.' },
    { id: 3, name: 'Leather Handbag', price: 1499.99, image: 'handbag.jpg', description: 'Luxury leather handbag with gold accents.' },
    { id: 4, name: 'Gold Necklace', price: 299.99, image: 'necklace.jpg', description: 'Delicate gold chain necklace.' },
    { id: 5, name: 'Silk Scarf', price: 199.99, image: 'scarf.jpg', description: 'Premium silk scarf in maroon and gold.' },
    { id: 6, name: 'Designer Heels', price: 799.99, image: 'heels.jpg', description: 'Comfortable designer heels in black.' }
  ];
  function getCart() { return JSON.parse(localStorage.getItem('somsCart') || '[]'); }
  function saveCart(c) { localStorage.setItem('somsCart', JSON.stringify(c)); }
  function updateCartCount() {
    const cart = getCart();
    const count = cart.reduce((s, i) => s + i.quantity, 0);
    let badge = qs('#cart-count');
    if (!badge) {
      const icon = qs('#cart-icon');
      if (icon) badge = create('span', { id: 'cart-count', style: 'margin-left:6px;font-weight:700' }, icon);
    }
    if (badge) badge.textContent = count;
  }
  function addToCartByInfo(product) {
    const cart = getCart();
    const idx = cart.findIndex(i => i.id === product.id);
    if (idx > -1) cart[idx].quantity++;
    else cart.push({ ...product, quantity: 1 });
    saveCart(cart); updateCartCount();
  }

  function initAddToCartDelegation(productsList = defaultProducts) {
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('.add-to-cart, .btn.add-to-cart');
      if (!btn) return;
      const pid = btn.dataset.productId || btn.dataset.product;
      if (pid) {
        const product = productsList.find(p => String(p.id) === String(pid) || p.name === pid);
        if (product) addToCartByInfo(product);
      } else {
        const name = btn.dataset.product || btn.getAttribute('data-product');
        const price = parseFloat(btn.dataset.price || btn.getAttribute('data-price') || 0);
        const product = { id: Date.now(), name: name || 'Item', price: price || 0, image: btn.dataset.image || '' };
        addToCartByInfo(product);
      }
    });
  }

  function ensureCartUI() {
    if (!qs('#cart-icon')) {
      const icon = create('div', { id: 'cart-icon', style: 'position:fixed;bottom:18px;right:18px;background:#8B0000;color:#fff;padding:10px 14px;border-radius:999px;cursor:pointer;z-index:1200' }, document.body);
      icon.innerHTML = '🛒 <span id="cart-count">0</span>';
      icon.addEventListener('click', openCartModal);
    }
    if (!qs('#cart-modal')) {
      const modal = create('div', { id: 'cart-modal', style: 'display:none;position:fixed;inset:0;background:rgba(0,0,0,0.4);z-index:1300;align-items:center;justify-content:center' }, document.body);
      const content = create('div', { id: 'cart-modal-content', style: 'background:#fff;padding:18px;border-radius:8px;width:95%;max-width:680px;max-height:85vh;overflow:auto' }, modal);
      content.innerHTML = '<button id="cart-close" style="float:right;border:0;background:transparent;font-size:22px;cursor:pointer">&times;</button><h3>Shopping Cart</h3><div id="cart-items"></div><p style="text-align:right;font-weight:700">Total: R<span id="cart-total">0.00</span></p><div style="display:flex;gap:8px;justify-content:flex-end"><button id="cart-checkout" class="primary">Checkout</button><button id="cart-clear" class="muted">Clear</button></div>';
      qs('#cart-close').addEventListener('click', closeCartModal);
      qs('#cart-clear').addEventListener('click', () => { saveCart([]); updateCartCount(); renderCart(); });
      qs('#cart-checkout').addEventListener('click', () => {
        const cart = getCart();
        if (!cart.length) return alert('Cart is empty');
        alert('Checkout simulated. Total: R' + cart.reduce((s,i)=>s+i.price*i.quantity,0).toFixed(2));
        saveCart([]); updateCartCount(); renderCart(); closeCartModal();
      });
      modal.addEventListener('click', (e) => { if (e.target === modal) closeCartModal(); });
    }
  }

  function openCartModal() { qs('#cart-modal').style.display = 'flex'; renderCart(); }
  function closeCartModal() { qs('#cart-modal').style.display = 'none'; }

  function renderCart() {
    const cartItemsRoot = qs('#cart-items');
    const cart = getCart();
    if (!cart.length) { cartItemsRoot.innerHTML = '<p>Your cart is empty.</p>'; qs('#cart-total').textContent = '0.00'; return; }
    cartItemsRoot.innerHTML = cart.map(item => `
      <div style="display:flex;gap:12px;align-items:center;padding:8px 0;border-bottom:1px solid #eee">
        <div style="flex:1">
          <strong>${item.name}</strong><div style="color:#666">R${item.price.toFixed(2)}</div>
        </div>
        <div style="display:flex;gap:6px;align-items:center">
          <input type="number" min="1" value="${item.quantity}" data-product-id="${item.id}" class="cart-qty" style="width:60px;padding:6px;border:1px solid #ccc;border-radius:4px">
          <button data-remove-id="${item.id}" style="background:#c00;color:#fff;border:none;padding:6px 8px;border-radius:6px;cursor:pointer">Remove</button>
        </div>
      </div>
    `).join('');
    cartItemsRoot.querySelectorAll('[data-remove-id]').forEach(b => b.addEventListener('click', (e) => {
      const id = b.getAttribute('data-remove-id');
      let c = getCart(); c = c.filter(i => String(i.id) !== String(id)); saveCart(c); updateCartCount(); renderCart();
    }));
    cartItemsRoot.querySelectorAll('.cart-qty').forEach(inp => inp.addEventListener('change', (e) => {
      const id = inp.getAttribute('data-product-id'); let c = getCart(); const idx = c.findIndex(i => String(i.id) === String(id));
      if (idx > -1) { c[idx].quantity = Math.max(1, parseInt(inp.value) || 1); saveCart(c); updateCartCount(); renderCart(); }
    }));
    const total = cart.reduce((s, i) => s + (i.price * i.quantity), 0);
    qs('#cart-total').textContent = total.toFixed(2);
  }

  // ---------- Products rendering + search ----------
  function renderProducts(gridEl, productsList) {
    gridEl.innerHTML = productsList.map(p => `
      <div class="card">
        <img src="${p.image}" alt="${p.name}" loading="lazy" />
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <div class="price">R${p.price.toFixed(2)}</div>
        <button class="btn add-to-cart" data-product-id="${p.id}">Add to Cart</button>
      </div>
    `).join('');
    initLightbox();
  }

  function initProductArea() {
    const grid = qs('#products-grid');
    if (!grid) return;
    const search = qs('#product-search');
    let list = defaultProducts.slice();
    renderProducts(grid, list);
    if (search) {
      search.addEventListener('input', () => {
        const term = search.value.trim().toLowerCase();
        const filtered = list.filter(p => p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term));
        renderProducts(grid, filtered);
      });
    }
  }

  // ---------- Init ----------
  function initAll() {
    initHamburger();
    initAccordions();
    initFormValidation();
    initLightbox();
    ensureCartUI();
    updateCartCount();
    initAddToCartDelegation(defaultProducts);
    initProductArea();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initAll);
  else initAll();

  // small API
  window.soms = { addToCartByInfo, openCartModal, getCart, saveCart };
})();

// Robust script for About/Services: toggleInfo, hamburger, cart (view/update/checkout)

window.toggleInfo = function(sectionId, button) {
  const content = document.getElementById(sectionId);
  if (!content) return;
  if (!button && typeof event !== 'undefined') button = event.target;
  const wasHidden = content.classList.contains('hidden');
  if (wasHidden) {
    content.classList.remove('hidden');
    if (button) button.textContent = 'Read Less';
  } else {
    content.classList.add('hidden');
    if (button) button.textContent = 'Read More';
  }
};

document.addEventListener('DOMContentLoaded', () => {
  const hamburger = document.getElementById('hamburger-menu');
  const nav = document.getElementById('main-nav');

  if (hamburger && nav) {
    hamburger.setAttribute('aria-expanded', 'false');
    hamburger.addEventListener('click', () => {
      const opened = nav.classList.toggle('active');
      hamburger.setAttribute('aria-expanded', opened ? 'true' : 'false');
    });
    hamburger.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const opened = nav.classList.toggle('active');
        hamburger.setAttribute('aria-expanded', opened ? 'true' : 'false');
      }
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('active');
        hamburger.setAttribute('aria-expanded', 'false');
      });
    });
    document.addEventListener('click', (e) => {
      if (!nav.contains(e.target) && !hamburger.contains(e.target) && nav.classList.contains('active')) {
        nav.classList.remove('active');
        hamburger.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // --- Cart helpers ---
  function getCart() {
    try { return JSON.parse(localStorage.getItem('somsCart') || '[]'); }
    catch (e) { return []; }
  }
  function saveCart(cart) { localStorage.setItem('somsCart', JSON.stringify(cart)); }

  // Render cart count badge and ensure View Cart button exists
  function renderCartCount() {
    const cart = getCart();
    const count = cart.reduce((sum, item) => sum + (item.qty || 0), 0);

    let badge = document.getElementById('cart-count');
    if (!badge) {
      badge = document.createElement('span');
      badge.id = 'cart-count';
      badge.setAttribute('aria-live', 'polite');
      badge.style.cssText = 'display:inline-block; min-width:20px; padding:2px 6px; background:#8B0000; color:#fff; border-radius:12px; font-size:12px; margin-left:8px;';
      const header = document.querySelector('header') || document.body;
      header.appendChild(badge);
    }
    badge.textContent = count;
    badge.style.display = count ? 'inline-block' : 'none';

    // Ensure View Cart button
    let viewBtn = document.getElementById('view-cart-btn');
    if (!viewBtn) {
      viewBtn = document.createElement('button');
      viewBtn.id = 'view-cart-btn';
      viewBtn.textContent = 'View Cart';
      viewBtn.style.cssText = 'margin-left:8px; padding:6px 10px; background:#333; color:#fff; border:none; border-radius:4px; cursor:pointer;';
      viewBtn.addEventListener('click', openCart);
      const header = document.querySelector('header') || document.body;
      header.appendChild(viewBtn);
    }
  }

  // Simple toast
  function showToast(message) {
    let toast = document.getElementById('soms-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'soms-toast';
      toast.style.cssText = 'position:fixed; bottom:20px; right:20px; background:rgba(0,0,0,0.85); color:#fff; padding:10px 14px; border-radius:6px; z-index:9999; font-size:14px;';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.style.opacity = '1';
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => { toast.style.opacity = '0'; }, 2000);
  }

  // Add to cart logic used by product buttons
  function addToCart(product, price) {
    const cart = getCart();
    const idx = cart.findIndex(i => i.product === product);
    if (idx > -1) cart[idx].qty = (cart[idx].qty || 1) + 1;
    else cart.push({ product, price: Number(price) || 0, qty: 1 });
    saveCart(cart);
    renderCartCount();
    showToast(`${product} added to cart`);
  }

  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const product = btn.dataset.product || btn.getAttribute('aria-label') || 'Item';
      const price = btn.dataset.price || btn.getAttribute('data-price') || 0;
      addToCart(product, price);
    });
  });

  // --- Cart UI / Modal ---
  function ensureCartModal() {
    if (document.getElementById('soms-cart-modal')) return;
    const modal = document.createElement('div');
    modal.id = 'soms-cart-modal';
    modal.style.cssText = 'position:fixed; inset:0; display:none; align-items:center; justify-content:center; background:rgba(0,0,0,0.5); z-index:10000;';
    modal.innerHTML = `
      <div id="soms-cart-panel" style="width:90%; max-width:720px; background:#fff; border-radius:8px; padding:16px; box-shadow:0 8px 24px rgba(0,0,0,0.3);">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <h3 style="margin:0;">Your Cart</h3>
          <div>
            <button id="soms-clear-cart" style="margin-right:8px; padding:6px 10px; background:#aaa; color:#fff; border:none; border-radius:4px; cursor:pointer;">Clear</button>
            <button id="soms-close-cart" style="padding:6px 10px; background:#8B0000; color:#fff; border:none; border-radius:4px; cursor:pointer;">Close</button>
          </div>
        </div>
        <div id="soms-cart-items" style="max-height:400px; overflow:auto; margin-bottom:12px;"></div>
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div id="soms-cart-summary" style="font-weight:600;"></div>
          <button id="soms-checkout" style="padding:8px 14px; background:#008000; color:#fff; border:none; border-radius:4px; cursor:pointer;">Checkout</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeCart();
    });
    document.getElementById('soms-close-cart').addEventListener('click', closeCart);
    document.getElementById('soms-clear-cart').addEventListener('click', () => {
      saveCart([]); renderCartCount(); renderCartItems(); showToast('Cart cleared');
    });
    document.getElementById('soms-checkout').addEventListener('click', checkout);
  }

  function openCart() {
    ensureCartModal();
    renderCartItems();
    document.getElementById('soms-cart-modal').style.display = 'flex';
  }
  function closeCart() {
    const modal = document.getElementById('soms-cart-modal');
    if (modal) modal.style.display = 'none';
  }

  function renderCartItems() {
    ensureCartModal();
    const container = document.getElementById('soms-cart-items');
    const summary = document.getElementById('soms-cart-summary');
    const cart = getCart();
    container.innerHTML = '';
    if (!cart || cart.length === 0) {
      container.innerHTML = '<p>Your cart is empty.</p>';
      summary.textContent = 'Total: R0.00';
      return;
    }
    let total = 0;
    cart.forEach((item, idx) => {
      const lineTotal = (item.price || 0) * (item.qty || 1);
      total += lineTotal;
      const row = document.createElement('div');
      row.style.cssText = 'display:flex; justify-content:space-between; align-items:center; gap:12px; padding:8px 0; border-bottom:1px solid #eee;';
      row.innerHTML = `
        <div style="flex:1;">
          <div style="font-weight:600;">${escapeHtml(item.product)}</div>
          <div style="font-size:13px; color:#666;">R${Number(item.price).toFixed(2)} each</div>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
          <button class="qty-decr" data-idx="${idx}" style="padding:4px 8px;">-</button>
          <span style="min-width:26px; text-align:center;">${item.qty}</span>
          <button class="qty-incr" data-idx="${idx}" style="padding:4px 8px;">+</button>
          <div style="width:16px;"></div>
          <div style="font-weight:600;">R${lineTotal.toFixed(2)}</div>
          <button class="remove-item" data-idx="${idx}" style="margin-left:8px; padding:4px 6px; background:#c00; color:#fff; border:none; border-radius:4px; cursor:pointer;">Remove</button>
        </div>
      `;
      container.appendChild(row);
    });
    summary.textContent = `Total: R${total.toFixed(2)}`;

    // wire qty and remove buttons
    container.querySelectorAll('.qty-incr').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.idx);
        changeQty(i, 1);
      });
    });
    container.querySelectorAll('.qty-decr').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.idx);
        changeQty(i, -1);
      });
    });
    container.querySelectorAll('.remove-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.idx);
        removeItem(i);
      });
    });
  }

  function changeQty(index, delta) {
    const cart = getCart();
    if (!cart[index]) return;
    cart[index].qty = Math.max(0, (cart[index].qty || 1) + delta);
    if (cart[index].qty === 0) cart.splice(index, 1);
    saveCart(cart);
    renderCartCount();
    renderCartItems();
  }

  function removeItem(index) {
    const cart = getCart();
    if (!cart[index]) return;
    cart.splice(index, 1);
    saveCart(cart);
    renderCartCount();
    renderCartItems();
    showToast('Item removed');
  }

  function checkout() {
    const cart = getCart();
    if (!cart || cart.length === 0) { showToast('Cart is empty'); return; }

    // New: require account to checkout
    if (!isLoggedIn()) {
      promptLoginForCheckout();
      return;
    }

    // Simulated checkout - replace with real API in production
    showToast('Processing order...');
    setTimeout(() => {
      saveCart([]);
      renderCartCount();
      renderCartItems();
      closeCart();
      showToast('Order placed — thank you!');
    }, 900);
  }

  /* --- AUTH modal (signup/login) used when user attempts checkout --- */
  function createAuthModal() {
    if (document.getElementById('soms-auth-modal')) return;

    const modal = document.createElement('div');
    modal.id = 'soms-auth-modal';
    modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,0.6);z-index:10050;padding:16px;';
    modal.innerHTML = `
      <div style="width:100%; max-width:520px; background:#fff; border-radius:8px; padding:18px; box-shadow:0 8px 30px rgba(0,0,0,0.3);">
        <div style="display:flex; gap:8px; justify-content:center; margin-bottom:12px;">
          <button id="soms-tab-login" style="padding:8px 12px; background:#eee; border-radius:6px; border:none; cursor:pointer;">Login</button>
          <button id="soms-tab-signup" style="padding:8px 12px; background:#eee; border-radius:6px; border:none; cursor:pointer;">Sign Up</button>
        </div>

        <div id="soms-auth-message" style="text-align:center;color:#c00;margin-bottom:8px;min-height:18px;"></div>

        <form id="soms-login-form" style="display:none; gap:8px;">
          <div style="margin-bottom:8px;"><label>Email</label><input name="email" type="email" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="margin-bottom:8px;"><label>Password</label><input name="password" type="password" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="display:flex; gap:8px; justify-content:flex-end;">
            <button type="button" id="soms-auth-cancel" style="padding:8px 12px;background:#ccc;border:none;border-radius:6px;">Cancel</button>
            <button type="submit" style="padding:8px 12px;background:#8B0000;color:#fff;border:none;border-radius:6px;">Login</button>
          </div>
        </form>

        <form id="soms-signup-form" style="display:none; gap:8px;">
          <div style="margin-bottom:8px;"><label>Full name</label><input name="name" type="text" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="margin-bottom:8px;"><label>Email</label><input name="email" type="email" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="margin-bottom:8px;"><label>Password</label><input name="password" type="password" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="display:flex; gap:8px; justify-content:flex-end;">
            <button type="button" id="soms-auth-cancel-2" style="padding:8px 12px;background:#ccc;border:none;border-radius:6px;">Cancel</button>
            <button type="submit" style="padding:8px 12px;background:#8B0000;color:#fff;border:none;border-radius:6px;">Sign Up</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(modal);

    // tab buttons
    const tabLogin = document.getElementById('soms-tab-login');
    const tabSignup = document.getElementById('soms-tab-signup');
    const loginForm = document.getElementById('soms-login-form');
    const signupForm = document.getElementById('soms-signup-form');
    const message = document.getElementById('soms-auth-message');

    function showTab(mode) {
      message.textContent = '';
      if (mode === 'login') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        tabLogin.style.background = '#ddd';
        tabSignup.style.background = '#eee';
      } else {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
        tabLogin.style.background = '#eee';
        tabSignup.style.background = '#ddd';
      }
    }

    tabLogin.addEventListener('click', () => showTab('login'));
    tabSignup.addEventListener('click', () => showTab('signup'));

    // Cancel buttons
    document.getElementById('soms-auth-cancel').addEventListener('click', () => modal.style.display = 'none');
    document.getElementById('soms-auth-cancel-2').addEventListener('click', () => modal.style.display = 'none');

    // Signup submit
    signupForm.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const name = signupForm.querySelector('[name="name"]').value.trim();
      const email = signupForm.querySelector('[name="email"]').value.trim();
      // NOTE: password stored insecurely for demo only
      const password = signupForm.querySelector('[name="password"]').value;

      if (!name || !/^\S+@\S+\.\S+$/.test(email) || !password) {
        message.textContent = 'Please enter valid details.';
        return;
      }

      saveUser({ name, email, password });
      signInSession(email);
      showToast('Account created and signed in');
      modal.style.display = 'none';
      // call success callback if provided
      if (typeof modal._onSuccess === 'function') modal._onSuccess();
    });

    // Login submit
    loginForm.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const email = loginForm.querySelector('[name="email"]').value.trim();
      const password = loginForm.querySelector('[name="password"]').value;

      const stored = getStoredUser();
      if (stored && stored.email === email) {
        // demo: accept any password if stored user exists
        signInSession(email);
        showToast('Signed in');
        modal.style.display = 'none';
        if (typeof modal._onSuccess === 'function') modal._onSuccess();
        return;
      }
      message.textContent = 'No account found. Please sign up.';
    });

    // close when clicking outside panel
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });

    // default to login
    showTab('login');
  }

  window.openAuthModal = function(mode = 'login', onSuccess) {
    createAuthModal();
    const modal = document.getElementById('soms-auth-modal');
    if (!modal) return;
    modal._onSuccess = onSuccess;
    // show requested tab
    document.getElementById('soms-tab-login').click();
    if (mode === 'signup') document.getElementById('soms-tab-signup').click();
    modal.style.display = 'flex';
    // focus first input
    setTimeout(() => {
      const first = modal.querySelector('input');
      if (first) first.focus();
    }, 50);
  };

  // Replace promptLoginForCheckout to open auth modal instead of a separate prompt
  function promptLoginForCheckout() {
    // If already showing, do nothing
    if (document.getElementById('soms-auth-modal') && document.getElementById('soms-auth-modal').style.display === 'flex') return;
    // open modal and on success continue checkout
    openAuthAndThenCheckout();
  }

  function openAuthAndThenCheckout() {
    openAuthRetry();
    function openAuthRetry() {
      openAuthModalHelper();
    }
    function openAuthModalHelper() {
      // show auth modal, when succeeded call checkout again which will pass isLoggedIn check
      window.openAuthModal('login', () => {
        // after success try checkout again
        // call the original checkout flow (perform checkout)
        checkout(); // now user is logged in, checkout will proceed
      });
    }
  }

  // Modify checkout() earlier in file so it will call promptLoginForCheckout() when not logged in
  // (Assumes you already applied previous patch where checkout() checks isLoggedIn and calls promptLoginForCheckout)

  // ---------- Products rendering + search ----------
  function renderProducts(gridEl, productsList) {
    gridEl.innerHTML = productsList.map(p => `
      <div class="card">
        <img src="${p.image}" alt="${p.name}" loading="lazy" />
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <div class="price">R${p.price.toFixed(2)}</div>
        <button class="btn add-to-cart" data-product-id="${p.id}">Add to Cart</button>
      </div>
    `).join('');
    initLightbox();
  }

  function initProductArea() {
    const grid = qs('#products-grid');
    if (!grid) return;
    const search = qs('#product-search');
    let list = defaultProducts.slice();
    renderProducts(grid, list);
    if (search) {
      search.addEventListener('input', () => {
        const term = search.value.trim().toLowerCase();
        const filtered = list.filter(p => p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term));
        renderProducts(grid, filtered);
      });
    }
  }

  // ---------- Init ----------
  function initAll() {
    initHamburger();
    initAccordions();
    initFormValidation();
    initLightbox();
    ensureCartUI();
    updateCartCount();
    initAddToCartDelegation(defaultProducts);
    initProductArea();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initAll);
  else initAll();

  // small API
  window.soms = { addToCartByInfo, openCartModal, getCart, saveCart };
})();

// Robust script for About/Services: toggleInfo, hamburger, cart (view/update/checkout)

window.toggleInfo = function(sectionId, button) {
  const content = document.getElementById(sectionId);
  if (!content) return;
  if (!button && typeof event !== 'undefined') button = event.target;
  const wasHidden = content.classList.contains('hidden');
  if (wasHidden) {
    content.classList.remove('hidden');
    if (button) button.textContent = 'Read Less';
  } else {
    content.classList.add('hidden');
    if (button) button.textContent = 'Read More';
  }
};

document.addEventListener('DOMContentLoaded', () => {
  const hamburger = document.getElementById('hamburger-menu');
  const nav = document.getElementById('main-nav');

  if (hamburger && nav) {
    hamburger.setAttribute('aria-expanded', 'false');
    hamburger.addEventListener('click', () => {
      const opened = nav.classList.toggle('active');
      hamburger.setAttribute('aria-expanded', opened ? 'true' : 'false');
    });
    hamburger.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const opened = nav.classList.toggle('active');
        hamburger.setAttribute('aria-expanded', opened ? 'true' : 'false');
      }
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('active');
        hamburger.setAttribute('aria-expanded', 'false');
      });
    });
    document.addEventListener('click', (e) => {
      if (!nav.contains(e.target) && !hamburger.contains(e.target) && nav.classList.contains('active')) {
        nav.classList.remove('active');
        hamburger.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // --- Cart helpers ---
  function getCart() {
    try { return JSON.parse(localStorage.getItem('somsCart') || '[]'); }
    catch (e) { return []; }
  }
  function saveCart(cart) { localStorage.setItem('somsCart', JSON.stringify(cart)); }

  // Render cart count badge and ensure View Cart button exists
  function renderCartCount() {
    const cart = getCart();
    const count = cart.reduce((sum, item) => sum + (item.qty || 0), 0);

    let badge = document.getElementById('cart-count');
    if (!badge) {
      badge = document.createElement('span');
      badge.id = 'cart-count';
      badge.setAttribute('aria-live', 'polite');
      badge.style.cssText = 'display:inline-block; min-width:20px; padding:2px 6px; background:#8B0000; color:#fff; border-radius:12px; font-size:12px; margin-left:8px;';
      const header = document.querySelector('header') || document.body;
      header.appendChild(badge);
    }
    badge.textContent = count;
    badge.style.display = count ? 'inline-block' : 'none';

    // Ensure View Cart button
    let viewBtn = document.getElementById('view-cart-btn');
    if (!viewBtn) {
      viewBtn = document.createElement('button');
      viewBtn.id = 'view-cart-btn';
      viewBtn.textContent = 'View Cart';
      viewBtn.style.cssText = 'margin-left:8px; padding:6px 10px; background:#333; color:#fff; border:none; border-radius:4px; cursor:pointer;';
      viewBtn.addEventListener('click', openCart);
      const header = document.querySelector('header') || document.body;
      header.appendChild(viewBtn);
    }
  }

  // Simple toast
  function showToast(message) {
    let toast = document.getElementById('soms-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'soms-toast';
      toast.style.cssText = 'position:fixed; bottom:20px; right:20px; background:rgba(0,0,0,0.85); color:#fff; padding:10px 14px; border-radius:6px; z-index:9999; font-size:14px;';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.style.opacity = '1';
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => { toast.style.opacity = '0'; }, 2000);
  }

  // Add to cart logic used by product buttons
  function addToCart(product, price) {
    const cart = getCart();
    const idx = cart.findIndex(i => i.product === product);
    if (idx > -1) cart[idx].qty = (cart[idx].qty || 1) + 1;
    else cart.push({ product, price: Number(price) || 0, qty: 1 });
    saveCart(cart);
    renderCartCount();
    showToast(`${product} added to cart`);
  }

  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const product = btn.dataset.product || btn.getAttribute('aria-label') || 'Item';
      const price = btn.dataset.price || btn.getAttribute('data-price') || 0;
      addToCart(product, price);
    });
  });

  // --- Cart UI / Modal ---
  function ensureCartModal() {
    if (document.getElementById('soms-cart-modal')) return;
    const modal = document.createElement('div');
    modal.id = 'soms-cart-modal';
    modal.style.cssText = 'position:fixed; inset:0; display:none; align-items:center; justify-content:center; background:rgba(0,0,0,0.5); z-index:10000;';
    modal.innerHTML = `
      <div id="soms-cart-panel" style="width:90%; max-width:720px; background:#fff; border-radius:8px; padding:16px; box-shadow:0 8px 24px rgba(0,0,0,0.3);">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <h3 style="margin:0;">Your Cart</h3>
          <div>
            <button id="soms-clear-cart" style="margin-right:8px; padding:6px 10px; background:#aaa; color:#fff; border:none; border-radius:4px; cursor:pointer;">Clear</button>
            <button id="soms-close-cart" style="padding:6px 10px; background:#8B0000; color:#fff; border:none; border-radius:4px; cursor:pointer;">Close</button>
          </div>
        </div>
        <div id="soms-cart-items" style="max-height:400px; overflow:auto; margin-bottom:12px;"></div>
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div id="soms-cart-summary" style="font-weight:600;"></div>
          <button id="soms-checkout" style="padding:8px 14px; background:#008000; color:#fff; border:none; border-radius:4px; cursor:pointer;">Checkout</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeCart();
    });
    document.getElementById('soms-close-cart').addEventListener('click', closeCart);
    document.getElementById('soms-clear-cart').addEventListener('click', () => {
      saveCart([]); renderCartCount(); renderCartItems(); showToast('Cart cleared');
    });
    document.getElementById('soms-checkout').addEventListener('click', checkout);
  }

  function openCart() {
    ensureCartModal();
    renderCartItems();
    document.getElementById('soms-cart-modal').style.display = 'flex';
  }
  function closeCart() {
    const modal = document.getElementById('soms-cart-modal');
    if (modal) modal.style.display = 'none';
  }

  function renderCartItems() {
    ensureCartModal();
    const container = document.getElementById('soms-cart-items');
    const summary = document.getElementById('soms-cart-summary');
    const cart = getCart();
    container.innerHTML = '';
    if (!cart || cart.length === 0) {
      container.innerHTML = '<p>Your cart is empty.</p>';
      summary.textContent = 'Total: R0.00';
      return;
    }
    let total = 0;
    cart.forEach((item, idx) => {
      const lineTotal = (item.price || 0) * (item.qty || 1);
      total += lineTotal;
      const row = document.createElement('div');
      row.style.cssText = 'display:flex; justify-content:space-between; align-items:center; gap:12px; padding:8px 0; border-bottom:1px solid #eee;';
      row.innerHTML = `
        <div style="flex:1;">
          <div style="font-weight:600;">${escapeHtml(item.product)}</div>
          <div style="font-size:13px; color:#666;">R${Number(item.price).toFixed(2)} each</div>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
          <button class="qty-decr" data-idx="${idx}" style="padding:4px 8px;">-</button>
          <span style="min-width:26px; text-align:center;">${item.qty}</span>
          <button class="qty-incr" data-idx="${idx}" style="padding:4px 8px;">+</button>
          <div style="width:16px;"></div>
          <div style="font-weight:600;">R${lineTotal.toFixed(2)}</div>
          <button class="remove-item" data-idx="${idx}" style="margin-left:8px; padding:4px 6px; background:#c00; color:#fff; border:none; border-radius:4px; cursor:pointer;">Remove</button>
        </div>
      `;
      container.appendChild(row);
    });
    summary.textContent = `Total: R${total.toFixed(2)}`;

    // wire qty and remove buttons
    container.querySelectorAll('.qty-incr').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.idx);
        changeQty(i, 1);
      });
    });
    container.querySelectorAll('.qty-decr').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.idx);
        changeQty(i, -1);
      });
    });
    container.querySelectorAll('.remove-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.idx);
        removeItem(i);
      });
    });
  }

  function changeQty(index, delta) {
    const cart = getCart();
    if (!cart[index]) return;
    cart[index].qty = Math.max(0, (cart[index].qty || 1) + delta);
    if (cart[index].qty === 0) cart.splice(index, 1);
    saveCart(cart);
    renderCartCount();
    renderCartItems();
  }

  function removeItem(index) {
    const cart = getCart();
    if (!cart[index]) return;
    cart.splice(index, 1);
    saveCart(cart);
    renderCartCount();
    renderCartItems();
    showToast('Item removed');
  }

  function checkout() {
    const cart = getCart();
    if (!cart || cart.length === 0) { showToast('Cart is empty'); return; }

    // New: require account to checkout
    if (!isLoggedIn()) {
      promptLoginForCheckout();
      return;
    }

    // Simulated checkout - replace with real API in production
    showToast('Processing order...');
    setTimeout(() => {
      saveCart([]);
      renderCartCount();
      renderCartItems();
      closeCart();
      showToast('Order placed — thank you!');
    }, 900);
  }

  /* --- AUTH modal (signup/login) used when user attempts checkout --- */
  function createAuthModal() {
    if (document.getElementById('soms-auth-modal')) return;

    const modal = document.createElement('div');
    modal.id = 'soms-auth-modal';
    modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,0.6);z-index:10050;padding:16px;';
    modal.innerHTML = `
      <div style="width:100%; max-width:520px; background:#fff; border-radius:8px; padding:18px; box-shadow:0 8px 30px rgba(0,0,0,0.3);">
        <div style="display:flex; gap:8px; justify-content:center; margin-bottom:12px;">
          <button id="soms-tab-login" style="padding:8px 12px; background:#eee; border-radius:6px; border:none; cursor:pointer;">Login</button>
          <button id="soms-tab-signup" style="padding:8px 12px; background:#eee; border-radius:6px; border:none; cursor:pointer;">Sign Up</button>
        </div>

        <div id="soms-auth-message" style="text-align:center;color:#c00;margin-bottom:8px;min-height:18px;"></div>

        <form id="soms-login-form" style="display:none; gap:8px;">
          <div style="margin-bottom:8px;"><label>Email</label><input name="email" type="email" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="margin-bottom:8px;"><label>Password</label><input name="password" type="password" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="display:flex; gap:8px; justify-content:flex-end;">
            <button type="button" id="soms-auth-cancel" style="padding:8px 12px;background:#ccc;border:none;border-radius:6px;">Cancel</button>
            <button type="submit" style="padding:8px 12px;background:#8B0000;color:#fff;border:none;border-radius:6px;">Login</button>
          </div>
        </form>

        <form id="soms-signup-form" style="display:none; gap:8px;">
          <div style="margin-bottom:8px;"><label>Full name</label><input name="name" type="text" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="margin-bottom:8px;"><label>Email</label><input name="email" type="email" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="margin-bottom:8px;"><label>Password</label><input name="password" type="password" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="display:flex; gap:8px; justify-content:flex-end;">
            <button type="button" id="soms-auth-cancel-2" style="padding:8px 12px;background:#ccc;border:none;border-radius:6px;">Cancel</button>
            <button type="submit" style="padding:8px 12px;background:#8B0000;color:#fff;border:none;border-radius:6px;">Sign Up</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(modal);

    // tab buttons
    const tabLogin = document.getElementById('soms-tab-login');
    const tabSignup = document.getElementById('soms-tab-signup');
    const loginForm = document.getElementById('soms-login-form');
    const signupForm = document.getElementById('soms-signup-form');
    const message = document.getElementById('soms-auth-message');

    function showTab(mode) {
      message.textContent = '';
      if (mode === 'login') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        tabLogin.style.background = '#ddd';
        tabSignup.style.background = '#eee';
      } else {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
        tabLogin.style.background = '#eee';
        tabSignup.style.background = '#ddd';
      }
    }

    tabLogin.addEventListener('click', () => showTab('login'));
    tabSignup.addEventListener('click', () => showTab('signup'));

    // Cancel buttons
    document.getElementById('soms-auth-cancel').addEventListener('click', () => modal.style.display = 'none');
    document.getElementById('soms-auth-cancel-2').addEventListener('click', () => modal.style.display = 'none');

    // Signup submit
    signupForm.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const name = signupForm.querySelector('[name="name"]').value.trim();
      const email = signupForm.querySelector('[name="email"]').value.trim();
      // NOTE: password stored insecurely for demo only
      const password = signupForm.querySelector('[name="password"]').value;

      if (!name || !/^\S+@\S+\.\S+$/.test(email) || !password) {
        message.textContent = 'Please enter valid details.';
        return;
      }

      saveUser({ name, email, password });
      signInSession(email);
      showToast('Account created and signed in');
      modal.style.display = 'none';
      // call success callback if provided
      if (typeof modal._onSuccess === 'function') modal._onSuccess();
    });

    // Login submit
    loginForm.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const email = loginForm.querySelector('[name="email"]').value.trim();
      const password = loginForm.querySelector('[name="password"]').value;

      const stored = getStoredUser();
      if (stored && stored.email === email) {
        // demo: accept any password if stored user exists
        signInSession(email);
        showToast('Signed in');
        modal.style.display = 'none';
        if (typeof modal._onSuccess === 'function') modal._onSuccess();
        return;
      }
      message.textContent = 'No account found. Please sign up.';
    });

    // close when clicking outside panel
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });

    // default to login
    showTab('login');
  }

  window.openAuthModal = function(mode = 'login', onSuccess) {
    createAuthModal();
    const modal = document.getElementById('soms-auth-modal');
    if (!modal) return;
    modal._onSuccess = onSuccess;
    // show requested tab
    document.getElementById('soms-tab-login').click();
    if (mode === 'signup') document.getElementById('soms-tab-signup').click();
    modal.style.display = 'flex';
    // focus first input
    setTimeout(() => {
      const first = modal.querySelector('input');
      if (first) first.focus();
    }, 50);
  };

  // Replace promptLoginForCheckout to open auth modal instead of a separate prompt
  function promptLoginForCheckout() {
    // If already showing, do nothing
    if (document.getElementById('soms-auth-modal') && document.getElementById('soms-auth-modal').style.display === 'flex') return;
    // open modal and on success continue checkout
    openAuthAndThenCheckout();
  }

  function openAuthAndThenCheckout() {
    openAuthRetry();
    function openAuthRetry() {
      openAuthModalHelper();
    }
    function openAuthModalHelper() {
      // show auth modal, when succeeded call checkout again which will pass isLoggedIn check
      window.openAuthModal('login', () => {
        // after success try checkout again
        // call the original checkout flow (perform checkout)
        checkout(); // now user is logged in, checkout will proceed
      });
    }
  }

  // Modify checkout() earlier in file so it will call promptLoginForCheckout() when not logged in
  // (Assumes you already applied previous patch where checkout() checks isLoggedIn and calls promptLoginForCheckout)

  // ---------- Products rendering + search ----------
  function renderProducts(gridEl, productsList) {
    gridEl.innerHTML = productsList.map(p => `
      <div class="card">
        <img src="${p.image}" alt="${p.name}" loading="lazy" />
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <div class="price">R${p.price.toFixed(2)}</div>
        <button class="btn add-to-cart" data-product-id="${p.id}">Add to Cart</button>
      </div>
    `).join('');
    initLightbox();
  }

  function initProductArea() {
    const grid = qs('#products-grid');
    if (!grid) return;
    const search = qs('#product-search');
    let list = defaultProducts.slice();
    renderProducts(grid, list);
    if (search) {
      search.addEventListener('input', () => {
        const term = search.value.trim().toLowerCase();
        const filtered = list.filter(p => p.name.toLowerCase().includes(term) || p.description.toLowerCase().includes(term));
        renderProducts(grid, filtered);
      });
    }
  }

  // ---------- Init ----------
  function initAll() {
    initHamburger();
    initAccordions();
    initFormValidation();
    initLightbox();
    ensureCartUI();
    updateCartCount();
    initAddToCartDelegation(defaultProducts);
    initProductArea();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initAll);
  else initAll();

  // small API
  window.soms = { addToCartByInfo, openCartModal, getCart, saveCart };
})();

// Robust script for About/Services: toggleInfo, hamburger, cart (view/update/checkout)

window.toggleInfo = function(sectionId, button) {
  const content = document.getElementById(sectionId);
  if (!content) return;
  if (!button && typeof event !== 'undefined') button = event.target;
  const wasHidden = content.classList.contains('hidden');
  if (wasHidden) {
    content.classList.remove('hidden');
    if (button) button.textContent = 'Read Less';
  } else {
    content.classList.add('hidden');
    if (button) button.textContent = 'Read More';
  }
};

document.addEventListener('DOMContentLoaded', () => {
  const hamburger = document.getElementById('hamburger-menu');
  const nav = document.getElementById('main-nav');

  if (hamburger && nav) {
    hamburger.setAttribute('aria-expanded', 'false');
    hamburger.addEventListener('click', () => {
      const opened = nav.classList.toggle('active');
      hamburger.setAttribute('aria-expanded', opened ? 'true' : 'false');
    });
    hamburger.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const opened = nav.classList.toggle('active');
        hamburger.setAttribute('aria-expanded', opened ? 'true' : 'false');
      }
    });
    nav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        nav.classList.remove('active');
        hamburger.setAttribute('aria-expanded', 'false');
      });
    });
    document.addEventListener('click', (e) => {
      if (!nav.contains(e.target) && !hamburger.contains(e.target) && nav.classList.contains('active')) {
        nav.classList.remove('active');
        hamburger.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // --- Cart helpers ---
  function getCart() {
    try { return JSON.parse(localStorage.getItem('somsCart') || '[]'); }
    catch (e) { return []; }
  }
  function saveCart(cart) { localStorage.setItem('somsCart', JSON.stringify(cart)); }

  // Render cart count badge and ensure View Cart button exists
  function renderCartCount() {
    const cart = getCart();
    const count = cart.reduce((sum, item) => sum + (item.qty || 0), 0);

    let badge = document.getElementById('cart-count');
    if (!badge) {
      badge = document.createElement('span');
      badge.id = 'cart-count';
      badge.setAttribute('aria-live', 'polite');
      badge.style.cssText = 'display:inline-block; min-width:20px; padding:2px 6px; background:#8B0000; color:#fff; border-radius:12px; font-size:12px; margin-left:8px;';
      const header = document.querySelector('header') || document.body;
      header.appendChild(badge);
    }
    badge.textContent = count;
    badge.style.display = count ? 'inline-block' : 'none';

    // Ensure View Cart button
    let viewBtn = document.getElementById('view-cart-btn');
    if (!viewBtn) {
      viewBtn = document.createElement('button');
      viewBtn.id = 'view-cart-btn';
      viewBtn.textContent = 'View Cart';
      viewBtn.style.cssText = 'margin-left:8px; padding:6px 10px; background:#333; color:#fff; border:none; border-radius:4px; cursor:pointer;';
      viewBtn.addEventListener('click', openCart);
      const header = document.querySelector('header') || document.body;
      header.appendChild(viewBtn);
    }
  }

  // Simple toast
  function showToast(message) {
    let toast = document.getElementById('soms-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'soms-toast';
      toast.style.cssText = 'position:fixed; bottom:20px; right:20px; background:rgba(0,0,0,0.85); color:#fff; padding:10px 14px; border-radius:6px; z-index:9999; font-size:14px;';
      document.body.appendChild(toast);
    }
    toast.textContent = message;
    toast.style.opacity = '1';
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => { toast.style.opacity = '0'; }, 2000);
  }

  // Add to cart logic used by product buttons
  function addToCart(product, price) {
    const cart = getCart();
    const idx = cart.findIndex(i => i.product === product);
    if (idx > -1) cart[idx].qty = (cart[idx].qty || 1) + 1;
    else cart.push({ product, price: Number(price) || 0, qty: 1 });
    saveCart(cart);
    renderCartCount();
    showToast(`${product} added to cart`);
  }

  document.querySelectorAll('.add-to-cart').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const product = btn.dataset.product || btn.getAttribute('aria-label') || 'Item';
      const price = btn.dataset.price || btn.getAttribute('data-price') || 0;
      addToCart(product, price);
    });
  });

  // --- Cart UI / Modal ---
  function ensureCartModal() {
    if (document.getElementById('soms-cart-modal')) return;
    const modal = document.createElement('div');
    modal.id = 'soms-cart-modal';
    modal.style.cssText = 'position:fixed; inset:0; display:none; align-items:center; justify-content:center; background:rgba(0,0,0,0.5); z-index:10000;';
    modal.innerHTML = `
      <div id="soms-cart-panel" style="width:90%; max-width:720px; background:#fff; border-radius:8px; padding:16px; box-shadow:0 8px 24px rgba(0,0,0,0.3);">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:12px;">
          <h3 style="margin:0;">Your Cart</h3>
          <div>
            <button id="soms-clear-cart" style="margin-right:8px; padding:6px 10px; background:#aaa; color:#fff; border:none; border-radius:4px; cursor:pointer;">Clear</button>
            <button id="soms-close-cart" style="padding:6px 10px; background:#8B0000; color:#fff; border:none; border-radius:4px; cursor:pointer;">Close</button>
          </div>
        </div>
        <div id="soms-cart-items" style="max-height:400px; overflow:auto; margin-bottom:12px;"></div>
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div id="soms-cart-summary" style="font-weight:600;"></div>
          <button id="soms-checkout" style="padding:8px 14px; background:#008000; color:#fff; border:none; border-radius:4px; cursor:pointer;">Checkout</button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeCart();
    });
    document.getElementById('soms-close-cart').addEventListener('click', closeCart);
    document.getElementById('soms-clear-cart').addEventListener('click', () => {
      saveCart([]); renderCartCount(); renderCartItems(); showToast('Cart cleared');
    });
    document.getElementById('soms-checkout').addEventListener('click', checkout);
  }

  function openCart() {
    ensureCartModal();
    renderCartItems();
    document.getElementById('soms-cart-modal').style.display = 'flex';
  }
  function closeCart() {
    const modal = document.getElementById('soms-cart-modal');
    if (modal) modal.style.display = 'none';
  }

  function renderCartItems() {
    ensureCartModal();
    const container = document.getElementById('soms-cart-items');
    const summary = document.getElementById('soms-cart-summary');
    const cart = getCart();
    container.innerHTML = '';
    if (!cart || cart.length === 0) {
      container.innerHTML = '<p>Your cart is empty.</p>';
      summary.textContent = 'Total: R0.00';
      return;
    }
    let total = 0;
    cart.forEach((item, idx) => {
      const lineTotal = (item.price || 0) * (item.qty || 1);
      total += lineTotal;
      const row = document.createElement('div');
      row.style.cssText = 'display:flex; justify-content:space-between; align-items:center; gap:12px; padding:8px 0; border-bottom:1px solid #eee;';
      row.innerHTML = `
        <div style="flex:1;">
          <div style="font-weight:600;">${escapeHtml(item.product)}</div>
          <div style="font-size:13px; color:#666;">R${Number(item.price).toFixed(2)} each</div>
        </div>
        <div style="display:flex; align-items:center; gap:6px;">
          <button class="qty-decr" data-idx="${idx}" style="padding:4px 8px;">-</button>
          <span style="min-width:26px; text-align:center;">${item.qty}</span>
          <button class="qty-incr" data-idx="${idx}" style="padding:4px 8px;">+</button>
          <div style="width:16px;"></div>
          <div style="font-weight:600;">R${lineTotal.toFixed(2)}</div>
          <button class="remove-item" data-idx="${idx}" style="margin-left:8px; padding:4px 6px; background:#c00; color:#fff; border:none; border-radius:4px; cursor:pointer;">Remove</button>
        </div>
      `;
      container.appendChild(row);
    });
    summary.textContent = `Total: R${total.toFixed(2)}`;

    // wire qty and remove buttons
    container.querySelectorAll('.qty-incr').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.idx);
        changeQty(i, 1);
      });
    });
    container.querySelectorAll('.qty-decr').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.idx);
        changeQty(i, -1);
      });
    });
    container.querySelectorAll('.remove-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const i = Number(btn.dataset.idx);
        removeItem(i);
      });
    });
  }

  function changeQty(index, delta) {
    const cart = getCart();
    if (!cart[index]) return;
    cart[index].qty = Math.max(0, (cart[index].qty || 1) + delta);
    if (cart[index].qty === 0) cart.splice(index, 1);
    saveCart(cart);
    renderCartCount();
    renderCartItems();
  }

  function removeItem(index) {
    const cart = getCart();
    if (!cart[index]) return;
    cart.splice(index, 1);
    saveCart(cart);
    renderCartCount();
    renderCartItems();
    showToast('Item removed');
  }

  function checkout() {
  if (cart.length === 0) {
    alert('Your cart is empty!');
    return;
  }

  // ⛔ NEW: Block checkout if account does NOT exist
  if (!userHasAccount()) {
    alert('You need an account before checking out. Redirecting you to Account Centre...');
    window.location.href = "Account.html";
    return;
  }

  // Existing checkout logic below — unchanged ✔
  alert('Proceeding to checkout with ' + cart.length + ' item(s). Total: R' + cart.reduce((sum, item) => sum + (item.price * item.quantity), 0).toFixed(2));
  cart = [];
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartCount();
  closeCartModal();
}
function userHasAccount() {
  return localStorage.getItem("userAccount") !== null;
}
localStorage.setItem("userAccount", JSON.stringify(user));


  /* --- AUTH modal (signup/login) used when user attempts checkout --- */
  function createAuthModal() {
    if (document.getElementById('soms-auth-modal')) return;

    const modal = document.createElement('div');
    modal.id = 'soms-auth-modal';
    modal.style.cssText = 'position:fixed;inset:0;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,0.6);z-index:10050;padding:16px;';
    modal.innerHTML = `
      <div style="width:100%; max-width:520px; background:#fff; border-radius:8px; padding:18px; box-shadow:0 8px 30px rgba(0,0,0,0.3);">
        <div style="display:flex; gap:8px; justify-content:center; margin-bottom:12px;">
          <button id="soms-tab-login" style="padding:8px 12px; background:#eee; border-radius:6px; border:none; cursor:pointer;">Login</button>
          <button id="soms-tab-signup" style="padding:8px 12px; background:#eee; border-radius:6px; border:none; cursor:pointer;">Sign Up</button>
        </div>

        <div id="soms-auth-message" style="text-align:center;color:#c00;margin-bottom:8px;min-height:18px;"></div>

        <form id="soms-login-form" style="display:none; gap:8px;">
          <div style="margin-bottom:8px;"><label>Email</label><input name="email" type="email" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="margin-bottom:8px;"><label>Password</label><input name="password" type="password" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="display:flex; gap:8px; justify-content:flex-end;">
            <button type="button" id="soms-auth-cancel" style="padding:8px 12px;background:#ccc;border:none;border-radius:6px;">Cancel</button>
            <button type="submit" style="padding:8px 12px;background:#8B0000;color:#fff;border:none;border-radius:6px;">Login</button>
          </div>
        </form>

        <form id="soms-signup-form" style="display:none; gap:8px;">
          <div style="margin-bottom:8px;"><label>Full name</label><input name="name" type="text" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="margin-bottom:8px;"><label>Email</label><input name="email" type="email" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="margin-bottom:8px;"><label>Password</label><input name="password" type="password" required style="width:100%;padding:8px;border:1px solid #ccc;"></div>
          <div style="display:flex; gap:8px; justify-content:flex-end;">
            <button type="button" id="soms-auth-cancel-2" style="padding:8px 12px;background:#ccc;border:none;border-radius:6px;">Cancel</button>
            <button type="submit" style="padding:8px 12px;background:#8B0000;color:#fff;border:none;border-radius:6px;">Sign Up</button>
          </div>
        </form>
      </div>
    `;
    document.body.appendChild(modal);

    // tab buttons
    const tabLogin = document.getElementById('soms-tab-login');
    const tabSignup = document.getElementById('soms-tab-signup');
    const loginForm = document.getElementById('soms-login-form');
    const signupForm = document.getElementById('soms-signup-form');
    const message = document.getElementById('soms-auth-message');

    function showTab(mode) {
      message.textContent = '';
      if (mode === 'login') {
        loginForm.style.display = 'block';
        signupForm.style.display = 'none';
        tabLogin.style.background = '#ddd';
        tabSignup.style.background = '#eee';
      } else {
        loginForm.style.display = 'none';
        signupForm.style.display = 'block';
        tabLogin.style.background = '#eee';
        tabSignup.style.background = '#ddd';
      }
    }

    tabLogin.addEventListener('click', () => showTab('login'));
    tabSignup.addEventListener('click', () => showTab('signup'));

    // Cancel buttons
    document.getElementById('soms-auth-cancel').addEventListener('click', () => modal.style.display = 'none');
    document.getElementById('soms-auth-cancel-2').addEventListener('click', () => modal.style.display = 'none');

    // Signup submit
    signupForm.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const name = signupForm.querySelector('[name="name"]').value.trim();
      const email = signupForm.querySelector('[name="email"]').value.trim();
      // NOTE: password stored insecurely for demo only
      const password = signupForm.querySelector('[name="password"]').value;

      if (!name || !/^\S+@\S+\.\S+$/.test(email) || !password) {
        message.textContent = 'Please enter valid details.';
        return;
      }

      saveUser({ name, email, password });
      signInSession(email);
      showToast('Account created and signed in');
      modal.style.display = 'none';
      // call success callback if provided
      if (typeof modal._onSuccess === 'function') modal._onSuccess();
    });

    // Login submit
    loginForm.addEventListener('submit', (ev) => {
      ev.preventDefault();
      const email = loginForm.querySelector('[name="email"]').value.trim();
      const password = loginForm.querySelector('[name="password"]').value;

      const stored = getStoredUser();
      if (stored && stored.email === email) {
        // demo: accept any password if stored user exists
        signInSession(email);
        showToast('Signed in');
        modal.style.display = 'none';
        if (typeof modal._onSuccess === 'function') modal._onSuccess();
        return;
      }
      message.textContent = 'No account found. Please sign up.';
    });

    // close when clicking outside panel
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });

    // default to login
    showTab('login');
  }

  window.openAuthModal = function(mode = 'login', onSuccess) {
    createAuthModal();
    const modal = document.getElementById('soms-auth-modal');
    if (!modal) return;
    modal._onSuccess = onSuccess;
    // show requested tab
    document.getElementById('soms-tab-login').click();
    if (mode === 'signup') document.getElementById('soms-tab-signup').click();
    modal.style.display = 'flex';
    // focus first input
    setTimeout(() => {
      const first = modal.querySelector('input');
      if (first) first.focus();
    }, 50);
  };

  // Replace promptLoginForCheckout to open auth modal instead of a separate prompt
  function promptLoginForCheckout() {
    // If already showing, do nothing
    if (document.getElementById('soms-auth-modal') && document.getElementById('soms-auth-modal').style.display === 'flex') return;
    // open modal and on success continue checkout
    openAuthAndThenCheckout();
  }

  function openAuthAndThenCheckout() {
    openAuthRetry();
    function openAuthRetry() {
      openAuthModalHelper();
    }
    function openAuthModalHelper() {
      // show auth modal, when succeeded call checkout again which will pass isLoggedIn check
      window.openAuthModal('login', () => {
        // after success try checkout again
        // call the original checkout flow (perform checkout)
        checkout(); // now user is logged in, checkout will proceed
      });
    }
  }

  // Modify checkout() earlier in file so it will call promptLoginForCheckout() when not logged in
  // (Assumes you already applied previous patch where checkout() checks isLoggedIn and calls promptLoginForCheckout)